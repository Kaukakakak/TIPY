const darkmenu = (prefix) => {
	return `

            COMANDOS:


  *Comandos do ⚜𝘚𝘈𝘕𝘉𝘖𝘛⚜:*

➸ *${prefix}loli*
➸ *${prefix}hentai*
➸ *${prefix}dono*
➸ *${prefix}porno*
➸ *${prefix}boanoite*
➸ *${prefix}bomdia*
➸ *${prefix}boatarde*
➸ *${prefix}mia*
➸ *${prefix}mia1*
➸ *${prefix}mia2*
➸ *${prefix}belle*
➸ *${prefix}belle1*
➸ *${prefix}belle2*
➸ *${prefix}belle3*
➸ *${prefix}ayeko*

╔════════════════════
  TRADUZIDO POR *S4ANVIC *
  DUVIDAS? 👇
  WA.me/5544998179556
╚════════════════════`
}

exports.darkmenu = darkmenu








